package model;

public class CentralSystem {
}
