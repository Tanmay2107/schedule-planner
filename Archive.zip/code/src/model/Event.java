package model;

public class Event {

  // Hamsa does event constructor and
}
