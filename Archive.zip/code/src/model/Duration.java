package model;

public class Duration {

  private DayTime startTime;
  private DayTime endTime;

  // constructor
  public Duration(DayTime startTime, DayTime endTime){

    //
  }

}
