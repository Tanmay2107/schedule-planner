package model;

public class UserSchedule {

}
