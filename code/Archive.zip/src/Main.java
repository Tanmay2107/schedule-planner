import java.util.ArrayList;
import java.util.List;

import model.CentralSystem;
import model.Day;
import model.DayTime;
import model.Event;
import model.IEvent;
import model.IUsers;
import model.ReadOnlyEvent;
import model.ReadOnlyUsers;
import model.UserSchedule;

public class Main {
  public static void main(String[] args) {

  }
}